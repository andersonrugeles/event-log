export default {
    region: 'us-east-2'
};
