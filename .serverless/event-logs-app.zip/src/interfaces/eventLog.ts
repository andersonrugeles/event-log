export interface EventData {
    eventId: string;
    eventDate: string;
    eventType: string;
    description: string;
}
